import unittest
import json
import sys
import os

# Adicionar o diretório da API ao path para importação
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '../../api')))

from app import app

class TestAPI(unittest.TestCase):
    """Testes da API usando unittest"""
    
    def setUp(self):
        """Configuração inicial para cada teste"""
        self.app = app.test_client()
        self.app.testing = True
    
    def test_get_items(self):
        """Testa o endpoint GET /api/items"""
        response = self.app.get('/api/items')
        self.assertEqual(response.status_code, 200)
        data = json.loads(response.data)
        self.assertIn('items', data)
        self.assertIn('count', data)
        self.assertIsInstance(data['items'], list)
        self.assertEqual(data['count'], len(data['items']))
    
    def test_get_item_by_id(self):
        """Testa o endpoint GET /api/items/{item_id}"""
        # Primeiro, verifica um item que deve existir (ID 0)
        response = self.app.get('/api/items/0')
        self.assertEqual(response.status_code, 200)
        data = json.loads(response.data)
        self.assertIn('item', data)
        self.assertEqual(data['item']['id'], 0)
        
        # Depois, verifica um item que não deve existir
        response = self.app.get('/api/items/999')
        self.assertEqual(response.status_code, 404)
        data = json.loads(response.data)
        self.assertIn('error', data)
    
    def test_create_item(self):
        """Testa o endpoint POST /api/items"""
        # Testa criação de item com dados válidos
        response = self.app.post(
            '/api/items',
            data=json.dumps({'name': 'Item de Teste Unittest', 'description': 'Descrição do item de teste'}),
            content_type='application/json'
        )
        self.assertEqual(response.status_code, 201)
        data = json.loads(response.data)
        self.assertIn('message', data)
        self.assertIn('item', data)
        self.assertEqual(data['item']['name'], 'Item de Teste Unittest')
        
        # Testa criação de item com dados inválidos (sem o campo obrigatório 'name')
        response = self.app.post(
            '/api/items',
            data=json.dumps({'description': 'Descrição sem nome'}),
            content_type='application/json'
        )
        self.assertEqual(response.status_code, 400)
        data = json.loads(response.data)
        self.assertIn('error', data)

if __name__ == '__main__':
    unittest.main()
